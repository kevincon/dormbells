***********************************************************

Texas Instruments MSP430 USB Developers Package

***********************************************************

Package Contents:
-> MSP430 Code (USB API & Application Examples):  
  -> Contains MSP430 USB API stacks for CDC, HID and composite examples.
  -> Contains a recommended Main Loop Framework (a heavily-commented framework from which to begin development)
-> MSP430 USB Descriptor Tool:
  -> Configures the API stack prior to development, and generates the USB descriptors.
  -> USB Stack 2.0 does not support MSC even though the descriptor tool supports this.
-> MSP430 HID USB Application:
  -> Similar to a terminal application (i.e., Hyperterminal), except for HID.  Use with the MSP430 Code USB API application examples.
-> MSP430 USB Firmware Upgrade Example:
  -> Allows customers to easily customize and release an installer package for upgrading MSP430-based devices in the field.
-> Programmer's Guide:  MSP430 USB API v2.0.
  ->A complete reference for developing USB software on the MSP430
  -> The CDC/HID API Stack Programmer's Guide documents everything in this directory.  See it for information about:
*  evaluating the stack and examples
*  writing applications
*  using the Descriptor Tool
*  links to other MSP430 USB information

Subdirectories also contain readme's with additional information.  
